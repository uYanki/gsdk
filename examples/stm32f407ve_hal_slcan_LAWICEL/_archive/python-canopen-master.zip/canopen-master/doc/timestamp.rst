Time Stamp Object (TIME)
========================

Usually the Time-Stamp object represents an absolute time in milliseconds after
midnight and the number of days since January 1, 1984. This is a bit sequence of
length 48 (6 bytes).


API
---

.. autoclass:: canopen.timestamp.TimeProducer
    :members:
