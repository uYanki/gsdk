# For classic bluetooth

- Pair with ESP_SPP_ACCEPTOR   
 If you are asked to enter the Pin Code, the Pin Code is "1234".   

- Launch the app and select device  
Menu->Devices->Bluetooth Classic   
![Android-1](https://user-images.githubusercontent.com/6020549/173160559-88c98af5-bb99-41ea-bd3d-1a7343fea5ad.JPG)

- Connect to device   
You can communicate to UNO using android.   
![Android-2](https://user-images.githubusercontent.com/6020549/173160564-4790a2cf-d084-400e-9a75-89cc2655f12e.JPG)

