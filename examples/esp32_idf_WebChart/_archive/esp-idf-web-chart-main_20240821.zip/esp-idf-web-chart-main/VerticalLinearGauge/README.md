# VerticalLinearGauge view
![web-vertical](https://user-images.githubusercontent.com/6020549/164379627-dac0078c-0a25-45bb-941f-d5588c87413b.jpg)

I used [this](https://canvas-gauges.com/) for gauge display.   
You can easily change the gauge design.   

