# RadialGauge view
![web-meter](https://user-images.githubusercontent.com/6020549/164379601-68aaf0e3-f50c-4776-8de1-216ce94d63df.jpg)

I used [this](https://canvas-gauges.com/) for gauge display.   
You can easily change the gauge design.   

