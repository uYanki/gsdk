# HorizontalLinearGauge view
![web-horizontal](https://user-images.githubusercontent.com/6020549/164379617-143ab49b-af77-4cfe-9d65-6f213d724d28.jpg)

I used [this](https://canvas-gauges.com/) for gauge display.   
You can easily change the gauge design.   

