# chart view using plotly
![Plotly](https://user-images.githubusercontent.com/6020549/164872660-be85b191-c0ed-4f06-b04c-1ba6c020d6d7.jpg)

I used [this](https://plotly.com/javascript/) for chart display.   
You can easily change the chart design.   

