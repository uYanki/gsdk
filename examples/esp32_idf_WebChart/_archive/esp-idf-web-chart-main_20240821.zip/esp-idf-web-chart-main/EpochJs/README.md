# chart view using epoch.js
![Epoch](https://user-images.githubusercontent.com/6020549/164948839-9a6997b3-6c40-441c-841e-be1a32b36890.jpg)

I used [this](https://epochjs.github.io/epoch/real-time/) for chart display.   
You can easily change the chart design.   


