# chart view using chart.js
![Chartjs](https://user-images.githubusercontent.com/6020549/164872690-abad13da-563f-44a4-b579-b4dd25598c33.jpg)

I used [this](https://nagix.github.io/chartjs-plugin-streaming/1.9.0/) for chart display.   
You can easily change the chart design.   

Document is [here](https://www.chartjs.org/docs/latest/).   

