
WebSockets ESP-IDF
==================

An example server for the websocket component on ESP-IDF using lwip netconn. The example can be made with `make` and uploaded with `make flash`.
