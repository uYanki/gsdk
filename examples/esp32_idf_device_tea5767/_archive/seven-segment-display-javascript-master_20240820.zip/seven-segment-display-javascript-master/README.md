For full details of this project go to
http://www.codedrome.com/seven-segment-display-in-javascript
