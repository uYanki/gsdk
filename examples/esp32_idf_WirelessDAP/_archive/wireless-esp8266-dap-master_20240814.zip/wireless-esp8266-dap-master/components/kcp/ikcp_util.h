#ifndef __IKCP_UTIL_H__
#define __IKCP_UTIL_H__

#include "components/kcp/ikcp.h"

IINT64 iclock64(void);
IUINT32 iclock();

#endif