#ifndef _UART_BRIDGE_H_
#define _UART_BRIDGE_H_


void uart_bridge_init();
void uart_bridge_task();
void uart_bridge_close();


#endif