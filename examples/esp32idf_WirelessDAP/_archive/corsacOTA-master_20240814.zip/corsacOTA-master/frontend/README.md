### Getting Started

dev:
```bash
$ npm run dev
```

build:
```bash
$ npm run build
```

### Default device address

simple route strategy:

For `192.168.2.1:3241`:
```
localhost:3000/?address=192.168.2.1:3241
```

`ota.local:3241` in other cases.