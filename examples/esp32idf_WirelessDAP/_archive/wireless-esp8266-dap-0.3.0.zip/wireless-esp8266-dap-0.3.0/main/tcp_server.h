#ifndef __TCP_SERVER_H__
#define __TCP_SERVER_H__

void tcp_server_task(void *pvParameters);

#endif