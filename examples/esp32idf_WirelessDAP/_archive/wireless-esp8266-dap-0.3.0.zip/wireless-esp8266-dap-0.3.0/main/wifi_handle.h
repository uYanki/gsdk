#ifndef _WIFI_HANDLE_H_
#define _WIFI_HANDLE_H_

void wifi_init();

#endif