﻿#ifndef PCH_H
#define PCH_H

#define ELL_DLL_USE_IMPORT 1
#include "../ipc_common.h"

#endif //PCH_H
