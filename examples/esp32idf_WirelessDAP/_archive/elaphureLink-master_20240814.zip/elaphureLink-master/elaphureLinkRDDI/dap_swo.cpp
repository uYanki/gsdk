﻿#include "pch.h"

/*


RDDI_FUNC int CMSIS_DAP_SWO_Baudrate(const RDDIHandle handle, int baudrate)
{
    //EL_TODO
    __debugbreak();
    return 8204;
}

RDDI_FUNC int CMSIS_DAP_SWO_Control(const RDDIHandle handle, int control)
{
    //EL_TODO
    __debugbreak();
    return 8204;
}



RDDI_FUNC int CMSIS_DAP_SWO_Status(const RDDIHandle handle, int *count, int *status)
{
    //EL_TODO
    __debugbreak();
    return 8204;
}



RDDI_FUNC int CMSIS_DAP_SWO_Data(const RDDIHandle handle, int *num_written, void *buffer, int *status)
{
    //EL_TODO
    __debugbreak();
    return 8204;
}

 *
 */