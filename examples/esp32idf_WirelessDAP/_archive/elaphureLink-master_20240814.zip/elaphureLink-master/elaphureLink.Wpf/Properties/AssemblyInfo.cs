﻿using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows;


[assembly: AssemblyTitle("elaphureLink.Wpf")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("elaphureLink.Wpf")]
[assembly: AssemblyCopyright("Copyright © windowsair. 2022")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]


[assembly: ComVisible(false)]


[assembly: ThemeInfo(
    ResourceDictionaryLocation.None,


    ResourceDictionaryLocation.SourceAssembly


)]



// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion(ThisAssembly.Git.BaseTag)]
[assembly: AssemblyFileVersion(ThisAssembly.Git.BaseTag)]
