#define VERSION_OF_SERVERS "SRV32-2.04-release" // development / release
