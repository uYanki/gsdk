#pragma once

#ifdef __cplusplus

  #include "ESP32-USBSoftHost.hpp"

#else

  #error ESP32-USB-Soft-Host requires a C++ compiler, please change file extension to .cc or .cpp

#endif

